import React from "react";

const Header = ({label}) =>{
    return(
        <h1>Calculo de Calorias {label}</h1>
    );
}

export default Header;